package arraylist;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		Products products = new Products();
		
		int choice = 0;
		
		while (choice != 3) {
			System.out.println("1. Add");
			System.out.println("2. Display");
			System.out.println("Exit");
			
			choice = scanner.nextInt();
			scanner.nextLine();
			
			switch (choice) {
			case 1:
				System.out.println("Enter the product");
				String product = scanner.nextLine();
				products.addProductToList(product);
			}
		}
	}

}
