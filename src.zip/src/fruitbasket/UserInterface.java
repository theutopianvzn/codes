package fruitbasket;

import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		FruitBasketUtility utility = new FruitBasketUtility();
		
		boolean flag = true;
		
		while (flag) {
			System.out.println("Select an option:");
			System.out.println("1. Add fruits");
			System.out.println("2. calcaulate bill");
			System.out.println("3. exit");
			
			int choice = Integer.parseInt(scanner.nextLine());
			
			switch (choice) {
			case 1:
				System.out.println("enter the fruit name");
				String nameString = scanner.nextLine();
				
				System.out.println("enter weight");
				int weight = scanner.nextInt();
				
				System.out.println("enter price per kg");
				int price = scanner.nextInt();
				scanner.nextLine();
				
				FruitBasket fBasket = new FruitBasket(nameString, weight, price);
				utility.addToBasket(fBasket);
				break;
				
			case 2:
				if (utility.getFruitBasketList().isEmpty()) {
					System.out.println("empty basket");
				} else {
					Stream<FruitBasket> stream = utility.getFruitBasketList().stream();
					int billAmount = utility.calculateBill(stream);
					System.out.println("price " + billAmount);
				}
				break;
				
			case 3:
				System.out.println("Thanks");
				flag = false;
				break;
				
			default:
				System.out.println("invalid");
				break;
			}
		}
		scanner.close();
	}

}
