package terminalops;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Launch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list = Arrays.asList(1, 2, 3);
		list.stream().skip(1).collect(Collectors.toList());
		list.stream().forEach(x -> System.out.println(x));
		
		list.stream().reduce((x, y) -> x + y).get(); //accumulate
		
		//anymatch, nonematch, allmatch
		boolean b = list.stream().anyMatch(x -> x % 2 == 0);
		System.out.println(b);
		
		boolean b1 = list.stream().allMatch(x -> x > 0);
		System.out.println(b1);
		
		boolean b2 = list.stream().noneMatch(x -> x < 0);
		System.out.println(b2);
		
		System.out.println(list.stream().findFirst().get());
		
		List<String> names = Arrays.asList("Anna", "Bob", "Charlie", "David");
		System.out.println(names.stream().filter(x -> x.length() > 3).toList());
		
		List<Integer> numbers = Arrays.asList(5, 2, 9, 1, 6);
		System.out.println(numbers.stream().map(x -> x * x).sorted().toList());
		
		String sentence = "Hello World";
		System.out.println(sentence.chars().filter(x -> x == 'l').count());
		
		List<Integer> numbers1 = Arrays.asList(1, 2, 3, 4, 5);
		
		LocalDate now = LocalDate.now();
	    LocalDate then = LocalDate.of(2004, 11, 14);
	    Period p = Period.between(now, then);
	    System.out.println(p);      // * P-21Y-2M-12D
	     
	   String date = "25/04/2003";
	   DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	   LocalDate localDate = LocalDate.parse(date, dateTimeFormatter);
	   System.out.println(localDate);      // * 2003-04-25

	}

}
