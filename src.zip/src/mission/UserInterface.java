package mission;

import java.util.Scanner;

public class UserInterface {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Mission 1 details:");
        int id1 = Integer.parseInt(sc.nextLine());
        String name1 = sc.nextLine();
        String operator1 = sc.nextLine();
        double budget1 = Double.parseDouble(sc.nextLine());
        String type1 = sc.nextLine();
        int year1 = Integer.parseInt(sc.nextLine());

        MissionInfo m1 = new MissionInfo(id1, name1, operator1, budget1, type1, year1);

        System.out.println("Enter Mission 2 details:");
        int id2 = Integer.parseInt(sc.nextLine());
        String name2 = sc.nextLine();
        String operator2 = sc.nextLine();
        double budget2 = Double.parseDouble(sc.nextLine());
        String type2 = sc.nextLine();
        int year2 = Integer.parseInt(sc.nextLine());

        MissionInfo m2 = new MissionInfo(id2, name2, operator2, budget2, type2, year2);

        System.out.println("\nMission Summary:");

        displayMission(m1);
        displayMission(m2);

        Mission higher = m1.getHigherValueMission(m1, m2);

        System.out.println("Higher Value Mission: " + 
            ((MissionInfo)higher).getMissionName() + " operated by " +
            ((MissionInfo)higher).getOperatorName());
    }

    public static void displayMission(MissionInfo m) {

        int years = Mission.getYearsInService(m.getLaunchYear());
        double perf = m.calculatePerformanceScore(years);
        double exp = m.calculateMaintenanceExpense(years);
        double risk = m.calculateRiskFactor(years);
        String level = m.getRiskLevel(risk);

        System.out.println();
        System.out.println(m.getMissionName() + " operated by " + m.getOperatorName());
        System.out.println("Years In Service: " + years);
        System.out.println("Performance Score: " + perf);
        System.out.println("Maintenance Expense: " + exp);
        System.out.println("Risk Level: " + level);
        System.out.println();
    }
}