package mission;

public interface Mission {

    public double calculatePerformanceScore(int yearsInService);

    public double calculateMaintenanceExpense(int yearsInService);

    public static int getYearsInService(int launchYear) {
        return 2026 - launchYear;
    }

    public default Mission getHigherValueMission(Mission m1, Mission m2) {
        int y1 = Mission.getYearsInService(((MissionInfo)m1).getLaunchYear());
        int y2 = Mission.getYearsInService(((MissionInfo)m2).getLaunchYear());

        double p1 = m1.calculatePerformanceScore(y1);
        double p2 = m2.calculatePerformanceScore(y2);

        return (p1 >= p2) ? m1 : m2;
    }
}
