package mission;

public interface RiskAssesable {

}
