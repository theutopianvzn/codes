package mission;

public class MissionInfo implements Mission, RiskAssesable {

    private int missionId;
    private String missionName;
    private String operatorName;
    private double baseBudget;
    private String missionType;
    private int launchYear;

    public MissionInfo(int missionId, String missionName, String operatorName,
                       double baseBudget, String missionType, int launchYear) {
        this.missionId = missionId;
        this.missionName = missionName;
        this.operatorName = operatorName;
        this.baseBudget = baseBudget;
        this.missionType = missionType;
        this.launchYear = launchYear;
    }

    // Getters
    public int getMissionId() { return missionId; }
    public String getMissionName() { return missionName; }
    public String getOperatorName() { return operatorName; }
    public double getBaseBudget() { return baseBudget; }
    public String getMissionType() { return missionType; }
    public int getLaunchYear() { return launchYear; }

    public double calculateRiskFactor(int yearsInService) {
        double multiplier = 0;

        switch (missionType) {
            case "Surveillance": multiplier = 1.8; break;
            case "Delivery": multiplier = 1.2; break;
            case "Research": multiplier = 2.5; break;
        }

        return yearsInService * multiplier;
    }

    @Override
    public double calculatePerformanceScore(int yearsInService) {
        double multiplier = 0;

        switch (missionType) {
            case "Surveillance": multiplier = 2.2; break;
            case "Delivery": multiplier = 1.5; break;
            case "Research": multiplier = 2.8; break;
        }

        double score = (yearsInService * multiplier * baseBudget) / 100.0;
        return Math.round(score * 10.0) / 10.0;
    }

    @Override
    public double calculateMaintenanceExpense(int yearsInService) {
        double rate = 0;

        switch (missionType) {
            case "Surveillance": rate = 1.1; break;
            case "Delivery": rate = 0.7; break;
            case "Research": rate = 1.6; break;
        }

        double exp = (yearsInService * rate * baseBudget) / 10.0;
        return Math.round(exp * 10.0) / 10.0;
    }
}
``