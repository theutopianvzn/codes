package exam;

public interface Exam {
	double calculateScore();
	
	public static String evaluateString(double percentage) {
		if (percentage >= 85) {
			return "Merit";
		} else if (percentage >= 60) {
			return "Pass";
		} else {
			return "Fail";
		}
	}
}
