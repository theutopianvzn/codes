package exam;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter exam details:");
		System.out.println("Student name:");
		String name = scanner.nextLine();
		
		System.out.println("question type");
		String type = scanner.nextLine();
		
		System.out.println("total questions:");
		int total = Integer.parseInt(scanner.nextLine());
		
		System.out.println("correct answers:");
		int correct = Integer.parseInt(scanner.nextLine());
		
		System.out.println("wrong answers:");
		int wrong = Integer.parseInt(scanner.nextLine());
		
		OnlineTest test = new OnlineTest(name, total, correct, wrong, type);
		
		double percentage = test.calculateScore();
		
		String resultString = Exam.evaluateString(percentage);
	}

}
