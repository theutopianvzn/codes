package map;

import java.util.HashMap;
import java.util.Set;

public class LaunchMap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "Akshit");
		map.put(2, "Neha");
		map.put(3,  "Shubham");
		
		System.out.println(map);
		System.out.println(map.get(3));
		
		System.out.println(map.containsKey(2));
		System.out.println(map.containsValue("Shubham"));
		
		Set<Integer> keySet = map.keySet();
		
		for (int i : keySet) {
			System.out.println(map.get(i));
		}
		
		map.remove(3);
		
		System.out.println(map);
	}

}
