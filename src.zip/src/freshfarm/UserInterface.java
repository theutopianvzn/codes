package freshfarm;

import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

//import javax.naming.InterruptedNamingException;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter number of cartons:");
		int n = Integer.parseInt(scanner.nextLine());
		
		if (n <= 0) {
			System.out.println("Invalid");
			return;
		}
		
//		System.out.println("Enter carton details");
//		String input = scanner.nextLine();
		
		List<Carton> list = new ArrayList<Carton>();
		
		for (int i = 0; i < n; i++) {
			System.out.println("Enter carton details");
			String input = scanner.nextLine();
			String[] parts = input.split("/");
			
			int quantity = Integer.parseInt(parts[1]);
			double cost = Double.parseDouble(parts[2]);
			
			if (quantity <= 0) {
				System.out.println("number should be positive");
				return;
			}
			
			Carton carton = new Carton();
			carton.setProductName(parts[0]);
			carton.setQuantity(quantity);
			
			list.add(carton);
		}
		
		CartonUtlity utility = new CartonUtlity();
		utility.setCartonList(list);
		
		Stream<Carton> stream = utility.convertToStream();
		Carton maxCarton = utility.findMax(stream);
		
		System.out.println(maxCarton.getProductName() + " had the highest quantity with " + maxCarton.getQuantity());
	}

}
