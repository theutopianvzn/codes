package CoolTrack;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class DataCenterUtility {
	private Set<DataCenter> dataCenterSet = new LinkedHashSet<DataCenter>();

	public Set<DataCenter> getDataCenterSet() {
		return dataCenterSet;
	}

	public void setDataCenterSet(Set<DataCenter> dataCenterSet) {
		this.dataCenterSet = dataCenterSet;
	}
	
	public void addDataCenter(DataCenter dataCenter) {
		dataCenterSet.add(dataCenter);
	}
	
	public DataCenter getDataCenterById(String dataCenterId) {
		for (DataCenter dc : dataCenterSet) {
			if (dc.getDataCenterId().equals(dataCenterId)) {
				return dc;
			}
		}
		return null;
	}
	
	public List<DataCenter> getDataCentersWithMaximumCoolingPowerUsage() {
		List<DataCenter> result = new ArrayList<DataCenter>();
		
		double max = Double.MIN_VALUE;
		
		for (DataCenter dc : dataCenterSet) {
			if (dc.getCoolingPowerUsage() > max) {
				max = dc.getCoolingPowerUsage();
			}
		}
		
		for (DataCenter dc : dataCenterSet) {
			if (dc.getCoolingPowerUsage() == max) {
				result.add(dc);
			}
		}
		
		return result;
	}
}
