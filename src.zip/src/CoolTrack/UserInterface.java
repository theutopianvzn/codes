package CoolTrack;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		DataCenterUtility utility = new DataCenterUtility();
		
		System.out.println("Enter the number of data centers to be added:");
		int n = Integer.parseInt(scanner.nextLine());
		
		System.out.println("Enter data center details");
		for (int i = 0; i < n; i++) {
			String input = scanner.nextLine();
			String[] parts = input.split(":");
			
			DataCenter dc = new DataCenter(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]));
			
			utility.addDataCenter(dc);
		}
		
		System.out.println("Enter the data center id:");
		String id = scanner.nextLine();
		
		DataCenter found = utility.getDataCenterById(id);
		
		if (found != null) {
			System.out.println(found.getDataCenterId() + "|" + found.getLocation() + "|" + found.getSuperVisorName() + "|" + found.getCoolingPowerUsage());
		} else {
			System.out.println("Data center not found");
		}
		
		System.out.println("data center with max cooling power usage");
		
		for (DataCenter dc : utility.getDataCentersWithMaximumCoolingPowerUsage()) {
			System.out.println(dc.getDataCenterId() + "|" + dc.getLocation() + "|" + dc.getSuperVisorName() + dc.getCoolingPowerUsage());
		}
		
		scanner.close();
	}

}
