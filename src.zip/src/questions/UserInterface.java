package questions;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		PizzaUtil util = new PizzaUtil();
		
		try {
			System.out.println("Enter pizza order details: ");
			String input = sc.nextLine();
			
			String[] parts = input.split(":");
			
			String orderId = parts[0];
			String pizzaType = parts[1];
			double basePrice = Double.parseDouble(parts[2]);
			int quantity = Integer.parseInt(parts[3]);
			
			util.validateOrderId(orderId);
			
			util.validateQuantity(quantity);
			
			util.validatePizzaType(pizzaType);
			
			double bill = util.calculateFinalBill(pizzaType, basePrice, quantity);
			
			System.out.println("Total bill for " + pizzaType + " pizzas: " + bill);
		} catch (InvalidPizzaOrderException e) {
			System.out.println(e.getMessage());
		}
	}

}
