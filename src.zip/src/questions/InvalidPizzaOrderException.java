package questions;

public class InvalidPizzaOrderException extends Exception {
	public InvalidPizzaOrderException(String message) {
		super(message);
	}
}
