package questions4;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter check in date and time");
        String checkInputString = scanner.nextLine();

        // STRICT FORMAT: yyyy/MM/dd HH:mm (24-hour format)
        DateTimeFormatter inputFormatter = DateTimeFormatter
                .ofPattern("yyyy/MM/dd HH:mm")
                .withResolverStyle(ResolverStyle.STRICT);

        LocalDateTime checkInDateTime;

        try {
            checkInDateTime = LocalDateTime.parse(checkInputString, inputFormatter);
        } catch (Exception e) {
            System.out.println(checkInputString + " is an invalid check in date or time");
            return;  // terminate the program
        }

        System.out.println("Enter number of hours of stay");
        int hours = scanner.nextInt();

        LocalDateTime checkOutDateTime = checkInDateTime.plusHours(hours);

        // OUTPUT FORMAT: yyyy-MM-dd hh:mm a (12-hour format)
        DateTimeFormatter outputFormatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");

        System.out.println("Check in Date and Time is " + checkInDateTime.format(outputFormatter).toUpperCase());
        System.out.println("Check out Date and Time is " + checkOutDateTime.format(outputFormatter).toUpperCase());
    }
}