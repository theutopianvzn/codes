package questions4;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String joiningDateStr = sc.nextLine();
		
		SimpleDateFormat sdf = new SimpleDateFormat();
		
		Date joiningDate = sdf.parse(joiningDateStr);
		Date currentDate = sdf.parse("15/12/2020");
		
		long diffInMillis = currentDate.getTime() - joiningDate.getTime();
		
		long years = diffInMillis / (1000L * 60 * 60 * 24 * 365);
		
		System.out.println(years + " years of experience");
	}

}
