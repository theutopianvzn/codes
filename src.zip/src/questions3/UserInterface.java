package questions3;

import java.util.Scanner;

public class UserInterface {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of gadget entries");
        int n = Integer.parseInt(sc.nextLine());

        for (int i = 1; i <= n; ) {

            System.out.println();
            System.out.println("Enter gadget " + i + " details");

            String input = sc.nextLine().trim();

            if (input.isEmpty()) {
                continue;
            }

            String[] parts = input.split(":");

            if (parts.length != 3) {
                System.out.println("Invalid input format");
                continue;
            }

            try {
                String gadgetID = parts[0];
                int warranty = Integer.parseInt(parts[2]);

                GadgetValidatorUtil gv = new GadgetValidatorUtil();

                gv.validateGadgetID(gadgetID);
                gv.validateWarrantyPeriod(warranty);

                System.out.println("Warranty accepted, stock updated");

                i++;

            } catch (InvalidGadgetException e) {
                System.out.println(e.getMessage());
            }
        }

        sc.close();
    }
}