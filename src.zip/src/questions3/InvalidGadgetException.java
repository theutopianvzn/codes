package questions3;

public class InvalidGadgetException extends Exception {
	public InvalidGadgetException(String message) {
		super(message);
	}
}
