package questions2;

public class SampleUtil {
	public boolean validateSampleCode(String sampleCode) throws SampleValidationException {
		if (!sampleCode.matches("SC-[1-9][0-9]{3}")) {
			throw new SampleValidationException("The sample code " + sampleCode + " is invalid");
		}
		return true;
	}
	
	public boolean validateAuthorizedLab(String labName) throws SampleValidationException {
		if (!(labName.equals("BioGenix") || labName.equals("NeuroLab") || labName.equals("CellMed") || labName.equals("GenPath"))) {
			throw new SampleValidationException("The lab name " + labName + " is invalid");
		}
		return true;
	}
	
	public boolean validateVolumeAcceptance(String labName, double volume) throws SampleValidationException {
		double max = 0;
		
		switch(labName) {
		case "BioGenix":
			max = 20;
			break;
			
		case "NeroLab":
			max = 15;
			break;
			
		case "CellMed":
			max = 10;
			break;
			
		case "GenPath":
			max = 25;
			break;
		}
		
		if (volume <= 0 || volume > max) {
			throw new SampleValidationException("invalid ml");
		}
		
		return true;
	}
	
	public double computeProcessingFee(String labName, double volume) {
		double rate = 0;
		
		switch(labName) {
		case "BioGenix":
			rate = 15;
			break;
			
		case "NeuroLab":
			rate = 20;
			break;
			
		case "CellMed":
			rate = 18;
			break;
			
		case "GenPath":
			rate = 12;
			break;
		}
		
		return volume * rate;
	}
}
