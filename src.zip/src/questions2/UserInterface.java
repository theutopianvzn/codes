package questions2;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		SampleUtil util = new SampleUtil();
		
		System.out.println("Enter sample details");
		String input = sc.nextLine();
		
		String[] parts = input.split(":");
		
		String sampleCode = parts[0];
		String labName = parts[1];
		double volume = Double.parseDouble(parts[2]);
		
		try {
			util.validateSampleCode(sampleCode);
			util.validateAuthorizedLab(labName);
			util.validateVolumeAcceptance(labName, volume);
			
			double fee = util.computeProcessingFee(labName, volume);
			
			System.out.println("Processing fee: $" + fee);
		} catch (SampleValidationException e) {
			System.out.println(e.getMessage());
		}
	}

}
