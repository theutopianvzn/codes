package questions2;

public class SampleValidationException extends Exception {
	public SampleValidationException(String message) {
		super(message);
	}
}
